chrome.runtime.onInstalled.addListener(() => {
    console.log("Installed");
})
