// to do
// - test current page queryselector at a tournament


document.querySelectorAll('[target="_blank"]').forEach(element => {
    element.removeAttribute("target");
});


